import React from 'react'

export default function Photos() {
    return (
        <div>
            Fotolar...
        </div>
    )
}
